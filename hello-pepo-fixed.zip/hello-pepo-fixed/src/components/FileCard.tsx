import React from "react";
import { Link } from "react-router-dom";
import { Download, File, Image as ImageIcon, Box } from "lucide-react";

interface FileCardProps {
  id: string;
  title: string;
  thumbnail: string | null;
  category: string;
  version: string;
  size: number;
  downloads: number;
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "Game APK":
    case "App":
      return <Box className="w-4 h-4" />;
    case "Mod":
      return <File className="w-4 h-4" />;
    case "Picture":
      return <ImageIcon className="w-4 h-4" />;
    default:
      return <File className="w-4 h-4" />;
  }
};

const formatSize = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
};

export function FileCard({ id, title, thumbnail, category, version, size, downloads }: FileCardProps) {
  return (
    <Link to={`/file/${id}`} className="group flex flex-col bg-slate-800 rounded-xl overflow-hidden border border-slate-700 hover:border-green-400/50 hover:shadow-[0_0_15px_rgba(74,222,128,0.1)] transition-all">
      <div className="aspect-[16/9] w-full bg-slate-700 relative overflow-hidden flex items-center justify-center">
        {thumbnail ? (
          <img src={`/uploads/${thumbnail}`} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        ) : (
          <div className="text-slate-500 flex flex-col items-center">
            {getCategoryIcon(category)}
            <span className="mt-2 text-xs">No Cover</span>
          </div>
        )}
        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded-md text-[10px] font-semibold text-green-400 border border-green-400/20">
          v{version}
        </div>
      </div>
      <div className="p-4 flex-1 flex flex-col">
        <h3 className="text-slate-100 font-semibold line-clamp-2 leading-snug group-hover:text-green-400 transition-colors">
          {title}
        </h3>
        <p className="text-slate-400 text-xs mt-1 flex items-center gap-1">
          {getCategoryIcon(category)} {category}
        </p>
        <div className="mt-auto pt-4 flex items-center justify-between text-xs text-slate-500 font-medium">
          <span>{formatSize(size)}</span>
          <span className="flex items-center gap-1">
            <Download className="w-3.5 h-3.5" />
            {downloads.toLocaleString()}
          </span>
        </div>
      </div>
    </Link>
  );
}
