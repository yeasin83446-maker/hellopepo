import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Search, Upload, Menu, Download, ShieldCheck } from "lucide-react";

export function Navbar() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = React.useState("");
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchTerm)}`);
    }
  };

  return (
    <nav className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <Download className="w-8 h-8 text-green-400" />
            <span className="text-xl font-bold text-white tracking-tight">
              Hello <span className="text-green-400">Pepo</span>
            </span>
          </Link>
          
          {/* Search bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <form onSubmit={handleSearch} className="w-full relative">
              <input
                type="text"
                placeholder="Search games, apps, mods..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-800 text-slate-100 placeholder-slate-400 border border-slate-700 rounded-full py-2 pl-4 pr-10 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent transition-all"
              />
              <button type="submit" className="absolute right-3 top-2.5 text-slate-400 hover:text-green-400">
                <Search className="w-5 h-5" />
              </button>
            </form>
          </div>

          {/* Nav Links */}
          <div className="hidden md:flex items-center gap-6">
            <Link to="/category/All" className="text-slate-300 hover:text-white transition-colors">Categories</Link>
            <Link to="/upload" className="text-slate-300 hover:text-white transition-colors flex items-center gap-2">
              <Upload className="w-4 h-4" /> Upload
            </Link>
            <Link to="/admin" className="text-slate-500 hover:text-slate-300 transition-colors" title="Admin">
              <ShieldCheck className="w-5 h-5" />
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button className="text-slate-300 hover:text-white">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
