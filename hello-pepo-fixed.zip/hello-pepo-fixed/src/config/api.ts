// API base URL
// In production: points to Render.com backend
// In development: empty string (same origin)
export const API_BASE_URL = (import.meta as any).env?.VITE_API_URL || "https://hello-pepo-api.onrender.com";
