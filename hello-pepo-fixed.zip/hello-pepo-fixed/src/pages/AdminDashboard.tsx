import React, { useState, useEffect } from "react";
import toast from "react-hot-toast";
import { ShieldCheck, LogIn, Check, Trash2, HardDrive, Download, Clock } from "lucide-react";

export function AdminDashboard() {
  const [token, setToken] = useState(localStorage.getItem("adminToken") || "");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  
  const [files, setFiles] = useState([]);
  const [stats, setStats] = useState({ totalUploads: 0, pendingUploads: 0, totalDownloads: 0 });
  const [loading, setLoading] = useState(false);

  const fetchDashboardData = () => {
    fetch("/api/admin/stats", {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => {
      if (!r.ok) {
        if(r.status === 401 || r.status === 403) setToken("");
        throw new Error("Failed to load stats");
      }
      return r.json();
    }).then(setStats).catch(console.error);

    fetch("/api/admin/files", {
      headers: { Authorization: `Bearer ${token}` }
    }).then(r => r.json()).then(setFiles).catch(console.error);
  };

  useEffect(() => {
    if (token) {
      localStorage.setItem("adminToken", token);
      fetchDashboardData();
    } else {
      localStorage.removeItem("adminToken");
    }
  }, [token]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setToken(data.token);
      toast.success("Logged in successfully");
    } catch (err: any) {
      toast.error(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const updateFileStatus = async (id: string, status: string) => {
    const isDelete = status === 'deleted';
    if (isDelete && !confirm("Are you sure you want to permanently delete this file?")) return;

    try {
      const res = await fetch(`/api/admin/files/${id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status })
      });
      if (!res.ok) throw new Error("Failed to update status");
      
      toast.success(isDelete ? "File deleted" : "File approved");
      fetchDashboardData();
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center px-4">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-500 to-cyan-500"></div>
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-slate-950 rounded-full border border-slate-800">
              <ShieldCheck className="w-8 h-8 text-green-400" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white text-center mb-2">Admin Portal</h2>
          <p className="text-slate-400 text-center text-sm mb-8">Sign in to manage Hello Pepo uploads</p>
          
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input 
                placeholder="Username (admin)" 
                value={username} onChange={e => setUsername(e.target.value)} required
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-3 focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
              />
            </div>
            <div>
              <input 
                type="password"
                placeholder="Password (admin123)" 
                value={password} onChange={e => setPassword(e.target.value)} required
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-3 focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
              />
            </div>
            <button 
              type="submit" disabled={loading}
              className="w-full py-3 bg-green-500 hover:bg-green-400 text-slate-950 font-bold rounded-lg transition-all flex justify-center items-center gap-2 mt-4"
            >
              <LogIn className="w-5 h-5" /> Sign In
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 py-8 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 border-b border-slate-800 pb-6">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-green-400" />
            <h1 className="text-3xl font-bold text-white tracking-tight">Dashboard</h1>
          </div>
          <button 
            onClick={() => setToken("")}
            className="mt-4 md:mt-0 px-4 py-2 bg-slate-900 border border-slate-700 text-slate-300 hover:text-white rounded-lg transition text-sm"
          >
            Logout
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex items-center gap-4">
            <div className="p-4 bg-blue-500/10 text-blue-400 rounded-xl"><HardDrive className="w-6 h-6" /></div>
            <div>
              <p className="text-slate-400 text-sm font-medium">Total Uploads</p>
              <h3 className="text-3xl font-bold text-white">{stats.totalUploads}</h3>
            </div>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex items-center gap-4">
            <div className="p-4 bg-yellow-500/10 text-yellow-500 rounded-xl"><Clock className="w-6 h-6" /></div>
            <div>
              <p className="text-slate-400 text-sm font-medium">Pending Approval</p>
              <h3 className="text-3xl font-bold text-white">{stats.pendingUploads}</h3>
            </div>
          </div>
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex items-center gap-4">
            <div className="p-4 bg-green-500/10 text-green-400 rounded-xl"><Download className="w-6 h-6" /></div>
            <div>
              <p className="text-slate-400 text-sm font-medium">Total Downloads</p>
              <h3 className="text-3xl font-bold text-white">{stats.totalDownloads}</h3>
            </div>
          </div>
        </div>

        <h2 className="text-xl font-bold text-white mb-4">Manage Files</h2>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-400">
              <thead className="bg-slate-800/50 text-slate-300 font-semibold uppercase text-xs">
                <tr>
                  <th className="px-6 py-4">File Name</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Category</th>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {files.map((f: any) => (
                  <tr key={f.id} className="hover:bg-slate-800/30 transition">
                    <td className="px-6 py-4 font-medium text-white block max-w-[200px] md:max-w-md truncate">
                      {f.title}
                    </td>
                    <td className="px-6 py-4">
                      {f.status === 'pending' ? (
                        <span className="px-2.5 py-1 bg-yellow-500/20 text-yellow-500 text-xs font-bold rounded-md uppercase">Pending</span>
                      ) : (
                        <span className="px-2.5 py-1 bg-green-500/20 text-green-400 text-xs font-bold rounded-md uppercase">Approved</span>
                      )}
                    </td>
                    <td className="px-6 py-4">{f.category}</td>
                    <td className="px-6 py-4">{new Date(f.uploadDate).toLocaleDateString()}</td>
                    <td className="px-6 py-4 text-right space-x-2 whitespace-nowrap">
                      {f.status === 'pending' && (
                        <button 
                          onClick={() => updateFileStatus(f.id, 'approved')}
                          className="px-3 py-1.5 bg-green-500 hover:bg-green-400 text-slate-950 font-bold rounded-lg transition text-xs inline-flex items-center gap-1"
                        >
                          <Check className="w-3 h-3" /> Approve
                        </button>
                      )}
                      <button 
                        onClick={() => updateFileStatus(f.id, 'deleted')}
                        className="px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 font-bold rounded-lg transition text-xs inline-flex items-center gap-1 border border-red-500/30"
                      >
                        <Trash2 className="w-3 h-3" /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
                {files.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-12 text-center text-slate-500">
                      No files uploaded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
