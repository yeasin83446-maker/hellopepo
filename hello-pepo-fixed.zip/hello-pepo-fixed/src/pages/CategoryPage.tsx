import React, { useEffect, useState } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { FileCard } from "../components/FileCard";
import { Filter, Layers } from "lucide-react";

export function CategoryPage() {
  const { categoryName } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);

  const currentSort = searchParams.get("sort") || "Latest";
  const name = categoryName || "All";

  useEffect(() => {
    setLoading(true);
    const qs = new URLSearchParams();
    if (name !== "All") qs.append("category", name);
    qs.append("sort", currentSort);

    fetch(`/api/files?${qs.toString()}`)
      .then(res => res.json())
      .then(data => {
        setFiles(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [name, currentSort]);

  const setSort = (sortStr: string) => {
    setSearchParams(prev => {
      prev.set("sort", sortStr);
      return prev;
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 py-12 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 border-b border-slate-800 pb-8">
          <div>
            <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight mb-2">
              {name === "All" ? "All Categories" : name}
            </h1>
            <p className="text-slate-400">Browse and download the best files in this category.</p>
          </div>
          
          <div className="flex items-center gap-3 bg-slate-900 p-2 rounded-xl border border-slate-800">
            <Filter className="w-5 h-5 text-slate-500 ml-2" />
            <div className="flex bg-slate-950 rounded-lg p-1 border border-slate-800">
              {["Latest", "Most Downloaded", "A-Z"].map(s => (
                <button
                  key={s}
                  onClick={() => setSort(s)}
                  className={`px-4 py-1.5 text-sm font-medium rounded-md transition ${currentSort === s ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-green-500/30 border-t-green-400 rounded-full animate-spin"></div>
          </div>
        ) : files.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {files.map((file: any) => (
              <FileCard key={file.id} {...file} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-900 rounded-2xl border border-slate-800">
            <Layers className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-slate-300 mb-2">No files found</h3>
            <p className="text-slate-500">There are no files in this category yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
