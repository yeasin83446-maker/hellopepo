import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import toast from "react-hot-toast";
import { Download, AlertTriangle, Calendar, HardDrive, Tag, Box, ArrowLeft, UploadCloud } from "lucide-react";

const formatSize = (bytes: number) => {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
};

export function FileDetailPage() {
  const { id } = useParams();
  const [file, setFile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);
  const [selectedVersionId, setSelectedVersionId] = useState<string>("");

  useEffect(() => {
    fetch(`/api/files/${id}`)
      .then(res => {
        if (!res.ok) throw new Error("File not found");
        return res.json();
      })
      .then(data => {
        setFile(data);
        if (data.versions && data.versions.length > 0) {
          // Sort versions descending
          data.versions.sort((a: any, b: any) => b.uploadDate - a.uploadDate);
          setSelectedVersionId(data.versions[0].id);
        }
        setLoading(false);
      })
      .catch(err => {
        toast.error(err.message);
        setLoading(false);
      });
  }, [id]);

  const handleDownload = async () => {
    try {
      setDownloading(true);
      // Update download count
      const res = await fetch(`/api/files/${id}/download`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setFile((prev: any) => ({ ...prev, downloads: data.downloads }));
        
        let targetFilename = file.filename;
        let targetOriginalName = file.originalName || file.filename;

        if (file.versions && selectedVersionId) {
          const selectedV = file.versions.find((v: any) => v.id === selectedVersionId);
          if (selectedV) {
            targetFilename = selectedV.filename;
            targetOriginalName = selectedV.originalName;
          }
        }

        // Trigger actual download
        const downloadUrl = `/uploads/${targetFilename}`;
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = targetOriginalName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
    } catch (e) {
      toast.error("Download failed to initiate.");
    } finally {
      setDownloading(false);
    }
  };

  const getDisplayVersion = () => {
    if (file && file.versions && selectedVersionId) {
      const selectedV = file.versions.find((v: any) => v.id === selectedVersionId);
      if (selectedV) return selectedV;
    }
    return file;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center">
        <div className="w-10 h-10 border-4 border-green-500/30 border-t-green-400 rounded-full animate-spin"></div>
        <p className="text-slate-400 mt-4 font-medium animate-pulse">Loading File Details...</p>
      </div>
    );
  }

  if (!file) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-center">
        <AlertTriangle className="w-16 h-16 text-yellow-500 mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">File not found</h2>
        <p className="text-slate-400 mb-6">This file might have been removed or is pending approval.</p>
        <Link to="/" className="px-6 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition">Go Home</Link>
      </div>
    );
  }

  const displayData = getDisplayVersion();

  return (
    <div className="min-h-screen bg-slate-950 py-8 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        <Link to="/" className="inline-flex items-center text-slate-400 hover:text-white mb-6 text-sm font-medium transition">
          <ArrowLeft className="w-4 h-4 mr-1" /> Back to Discover
        </Link>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Info */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
              {file.thumbnail ? (
                <div className="w-full aspect-[21/9] bg-slate-950">
                  <img src={`/uploads/${file.thumbnail}`} alt={file.title} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-full aspect-[21/9] bg-slate-950 flex items-center justify-center">
                   <Box className="w-20 h-20 text-slate-800" />
                </div>
              )}
              
              <div className="p-6 md:p-8">
                <div className="flex flex-wrap items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-green-500/10 text-green-400 text-xs font-bold rounded-lg border border-green-500/20 uppercase tracking-wider">
                    {file.category}
                  </span>
                  <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-xs font-bold rounded-lg border border-blue-500/20">
                    v{displayData?.version || file.version}
                  </span>
                </div>
                
                <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight mb-4 leading-tight">{file.title}</h1>
                
                <div className="prose prose-invert max-w-none text-slate-300 leading-relaxed">
                  <p className="whitespace-pre-wrap">{file.description}</p>
                </div>

                {file.tags && file.tags.length > 0 && (
                  <div className="mt-8 pt-6 border-t border-slate-800 flex flex-wrap gap-2">
                    <Tag className="w-4 h-4 text-slate-500 mt-0.5" />
                    {file.tags.map((tag: string, i: number) => (
                      <Link key={i} to={`/search?q=${encodeURIComponent(tag)}`} className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-md transition cursor-pointer">
                        #{tag}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sticky top-24 shadow-xl">
              <button 
                onClick={handleDownload}
                disabled={downloading}
                className="w-full h-16 bg-gradient-to-r from-green-500 to-green-400 hover:from-green-400 hover:to-green-300 text-slate-950 font-black text-xl rounded-xl shadow-[0_0_20px_rgba(74,222,128,0.3)] hover:shadow-[0_0_30px_rgba(74,222,128,0.5)] transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                <Download className="w-6 h-6" /> 
                {downloading ? "Starting Download..." : "Download Now"}
              </button>
              <div className="mt-4 text-center text-xs text-slate-500">
                Safe and Verified • {displayData?.originalName || file.originalName}
              </div>

              {file.versions && file.versions.length > 0 && (
                <div className="mt-6">
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">Select Version</label>
                  <select 
                    value={selectedVersionId}
                    onChange={(e) => setSelectedVersionId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 text-slate-200 text-sm rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-green-400 transition"
                  >
                    {file.versions.map((v: any, idx: number) => (
                      <option key={v.id} value={v.id}>
                        v{v.version} {idx === 0 ? "(Latest)" : ""}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="mt-6 space-y-4 pt-6 border-t border-slate-800">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 flex items-center gap-2"><HardDrive className="w-4 h-4" /> File Size</span>
                  <span className="font-semibold text-slate-200">{formatSize(displayData?.size || file.size)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 flex items-center gap-2"><Download className="w-4 h-4" /> Downloads (All)</span>
                  <span className="font-semibold text-slate-200">{file.downloads.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400 flex items-center gap-2"><Calendar className="w-4 h-4" /> Uploaded</span>
                  <span className="font-semibold text-slate-200">{new Date(displayData?.uploadDate || file.uploadDate).toLocaleDateString()}</span>
                </div>
              </div>

              <Link to={`/upload?updateForId=${file.id}`} className="w-full mt-8 py-3 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 text-sm font-semibold rounded-xl border border-blue-500/20 transition flex items-center justify-center gap-2">
                <UploadCloud className="w-4 h-4" /> Upload New Version
              </Link>
              <button className="w-full mt-4 py-3 bg-red-500/10 text-red-400 hover:bg-red-500/20 text-sm font-semibold rounded-xl border border-red-500/20 transition flex items-center justify-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Report File
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
