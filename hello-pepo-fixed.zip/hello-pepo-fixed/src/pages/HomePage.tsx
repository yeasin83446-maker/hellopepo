import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FileCard } from "../components/FileCard";
import { Layers, Gamepad2, Smartphone, Zap, Image as ImageIcon } from "lucide-react";

export function HomePage() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/files?sort=Latest")
      .then((res) => res.json())
      .then((data) => {
        setFiles(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to load files", err);
        setLoading(false);
      });
  }, []);

  const categories = [
    { name: "Game APK", icon: <Gamepad2 className="w-5 h-5" />, color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
    { name: "App", icon: <Smartphone className="w-5 h-5" />, color: "bg-purple-500/20 text-purple-400 border-purple-500/30" },
    { name: "Mod", icon: <Zap className="w-5 h-5" />, color: "bg-pink-500/20 text-pink-400 border-pink-500/30" },
    { name: "Picture", icon: <ImageIcon className="w-5 h-5" />, color: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
    { name: "Other", icon: <Layers className="w-5 h-5" />, color: "bg-green-500/20 text-green-400 border-green-500/30" }
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-20 border-b border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5 mix-blend-overlay"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-black text-white tracking-tight mb-4">
            Discover. Download. <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-cyan-400">Share.</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-10">
            Hello Pepo is your ultimate hub for Android APKs, exclusive game mods, apps, and community uploads.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((c) => (
              <Link 
                to={`/category/${encodeURIComponent(c.name)}`} 
                key={c.name}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-full border ${c.color} hover:bg-slate-800 transition-colors font-medium`}
              >
                {c.icon} {c.name}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Uploads */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Zap className="text-green-400" /> Latest Uploads
          </h2>
          <Link to="/category/All?sort=Latest" className="text-sm font-medium text-green-400 hover:text-green-300">
            View All →
          </Link>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-green-500/30 border-t-green-400 rounded-full animate-spin"></div>
          </div>
        ) : files.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {files.map((file: any) => (
              <FileCard key={file.id} {...file} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-900 rounded-2xl border border-slate-800">
            <Layers className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-slate-300 mb-2">No files yet</h3>
            <p className="text-slate-500">Be the first to upload a file to the community!</p>
          </div>
        )}
      </section>
    </div>
  );
}
