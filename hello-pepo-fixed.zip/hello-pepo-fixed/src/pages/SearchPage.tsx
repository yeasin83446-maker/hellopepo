import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { FileCard } from "../components/FileCard";
import { Search as SearchIcon } from "lucide-react";

export function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get("q") || "";
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!query) {
      setFiles([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    fetch(`/api/files?search=${encodeURIComponent(query)}`)
      .then(res => res.json())
      .then(data => {
        setFiles(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [query]);

  return (
    <div className="min-h-screen bg-slate-950 py-12 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
          Search Results
        </h1>
        <p className="text-slate-400 mb-10 pb-8 border-b border-slate-800">
          Showing results for <span className="text-green-400 font-semibold">"{query}"</span>
        </p>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-green-500/30 border-t-green-400 rounded-full animate-spin"></div>
          </div>
        ) : files.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {files.map((file: any) => (
              <FileCard key={file.id} {...file} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-900 rounded-2xl border border-slate-800">
            <SearchIcon className="w-12 h-12 text-slate-600 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-slate-300 mb-2">No results found</h3>
            <p className="text-slate-500">Try adjusting your search keywords.</p>
          </div>
        )}
      </div>
    </div>
  );
}
