import React, { useState, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";
import { UploadCloud, FileType, CheckCircle, Tag, Info, AlertTriangle, ShieldCheck } from "lucide-react";

import { API_BASE_URL } from "../config/api";
import axios from "axios";

export function UploadPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const updateForId = searchParams.get("updateForId");
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [captchaParams, setCaptchaParams] = useState({ num1: Math.floor(Math.random() * 10), num2: Math.floor(Math.random() * 10) });
  
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "Game APK",
    version: "1.0.0",
    tags: "",
    captchaAnswer: ""
  });
  
  useEffect(() => {
    if (updateForId) {
      axios.get(`${API_BASE_URL}/api/files/${updateForId}`)
        .then(res => {
          const data = res.data;
          setFormData(prev => ({
            ...prev,
            title: data.title || "",
            description: data.description || "",
            category: data.category || "Game APK",
            version: data.version || "1.0.0",
            tags: data.tags ? data.tags.join(", ") : ""
          }));
        })
        .catch(err => toast.error(err.response?.data?.message || err.message));
    }
  }, [updateForId]);

  const [file, setFile] = useState<File | null>(null);
  const [thumbnail, setThumbnail] = useState<File | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      toast.error("Please select a file to upload");
      return;
    }
    
    const expectedAnswer = captchaParams.num1 + captchaParams.num2;
    if (parseInt(formData.captchaAnswer) !== expectedAnswer) {
      toast.error("Incorrect CAPTCHA answer!");
      setCaptchaParams({ num1: Math.floor(Math.random() * 10), num2: Math.floor(Math.random() * 10) });
      setFormData(prev => ({ ...prev, captchaAnswer: "" }));
      return;
    }

    setLoading(true);
    setUploadProgress(0);
    const data = new FormData();
    data.append("file", file);
    if (thumbnail) data.append("thumbnail", thumbnail);
    data.append("title", formData.title);
    data.append("description", formData.description);
    data.append("category", formData.category);
    data.append("version", formData.version);
    data.append("tags", formData.tags);
    data.append("captchaAnswer", formData.captchaAnswer);
    data.append("captchaExpected", expectedAnswer.toString());
    if (updateForId) {
      data.append("updateForId", updateForId);
    }

    try {
      const res = await axios.post(`${API_BASE_URL}/api/upload`, data, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploadProgress(percentCompleted);
          }
        }
      });

      toast.success(res.data.message || "File uploaded! Waiting for admin approval.");
      setTimeout(() => navigate("/"), 2000);
    } catch (err: any) {
      toast.error(err.response?.data?.message || err.message || "An error occurred during upload.");
      setUploadProgress(0);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const MAX_SIZE = 500 * 1024 * 1024; // 500MB

  return (
    <div className="min-h-screen bg-slate-950 py-12 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 overflow-hidden">
        <div className="bg-gradient-to-r from-green-500/10 to-cyan-500/10 p-6 border-b border-slate-800 flex items-center gap-4">
          <div className="p-3 bg-green-400/20 text-green-400 rounded-xl">
            <UploadCloud className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">Upload File</h1>
            <p className="text-slate-400 text-sm">Share your mods, apps, and files with the Hello Pepo community (Max 500MB)</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                Title / File Name
              </label>
              <input 
                required 
                name="title" 
                maxLength={100}
                value={formData.title} 
                onChange={handleChange}
                placeholder="e.g. Minecraft PE Mod Menu v1.2"
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Category</label>
              <div className="relative">
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-2.5 appearance-none focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
                >
                  <option value="Game APK">Game APK</option>
                  <option value="App">App</option>
                  <option value="Mod">Mod</option>
                  <option value="Picture">Picture Pack</option>
                  <option value="Other">Other</option>
                </select>
                <FileType className="absolute right-3 top-3 w-4 h-4 text-slate-500 pointer-events-none" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Version Number</label>
              <input 
                name="version" 
                value={formData.version} 
                onChange={handleChange}
                placeholder="e.g. 1.0.0"
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-medium text-slate-300">Description</label>
              <textarea 
                required 
                name="description" 
                rows={4}
                value={formData.description} 
                onChange={handleChange}
                placeholder="Describe what this file is, how to install it, features, etc..."
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-green-400 focus:border-transparent transition resize-y"
              />
            </div>
            
            <div className="space-y-2 md:col-span-2">
              <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                <Tag className="w-4 h-4" /> Tags (comma separated)
              </label>
              <input 
                name="tags" 
                value={formData.tags} 
                onChange={handleChange}
                placeholder="fps, shooters, mod-menu, unlimited-coins"
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
              />
            </div>

            {/* File Uploads */}
            <div className="space-y-2 md:col-span-2 p-6 border-2 border-dashed border-slate-700 rounded-xl bg-slate-950/50 hover:bg-slate-950 transition-colors">
               <label className="text-sm font-medium text-slate-300 block mb-2">Main File <span className="text-red-400">*</span></label>
               <input 
                type="file" 
                required
                accept=".apk,.zip,.rar,.png,.jpg,.jpeg,.gif,.mp4"
                onChange={(e) => {
                  const selected = e.target.files?.[0];
                  if (selected && selected.size > MAX_SIZE) {
                    toast.error("File exceeds 500MB limit");
                    e.target.value = "";
                  } else {
                    setFile(selected || null);
                  }
                }}
                className="block w-full text-sm text-slate-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-green-400/10 file:text-green-400 hover:file:bg-green-400/20 transition-all cursor-pointer"
              />
              <p className="text-xs text-slate-500 mt-2">Accepted formats: .apk, .zip, .rar, .jpg, .png, .mp4</p>
            </div>

            <div className="space-y-2 md:col-span-2 p-6 border-2 border-dashed border-slate-700 rounded-xl bg-slate-950/50 hover:bg-slate-950 transition-colors">
               <label className="text-sm font-medium text-slate-300 block mb-2">Thumbnail Cover (Optional)</label>
               <input 
                type="file" 
                accept="image/*"
                onChange={(e) => setThumbnail(e.target.files?.[0] || null)}
                className="block w-full text-sm text-slate-400 file:mr-4 file:py-2.5 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-slate-800 file:text-slate-300 hover:file:bg-slate-700 transition-all cursor-pointer"
              />
            </div>

            {/* CAPTCHA */}
            <div className="space-y-2 md:col-span-2 bg-slate-950 p-4 rounded-lg border border-slate-800 flex items-center justify-between">
              <div>
                <label className="text-sm font-medium text-slate-300 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-green-400" /> Security Check
                </label>
                <p className="text-slate-400 text-xs mt-1">What is {captchaParams.num1} + {captchaParams.num2}?</p>
              </div>
              <input 
                required 
                type="number"
                name="captchaAnswer" 
                value={formData.captchaAnswer} 
                onChange={handleChange}
                className="w-24 bg-slate-900 border border-slate-700 text-white rounded-lg px-4 py-2 text-center text-lg font-mono focus:ring-2 focus:ring-green-400 focus:border-transparent transition"
              />
            </div>
            
          </div>

          <div className="pt-4 border-t border-slate-800 flex flex-col gap-4">
            {loading && uploadProgress > 0 && (
              <div className="w-full">
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Uploading...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-2.5">
                  <div 
                    className="bg-green-400 h-2.5 rounded-full transition-all duration-300" 
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            )}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-400/80 text-xs font-medium">
                <AlertTriangle className="w-4 h-4" />
                Uploads require Admin approval.
              </div>
              
              <button 
                type="submit" 
                disabled={loading}
                className="px-6 py-3 bg-green-500 hover:bg-green-400 disabled:opacity-50 disabled:hover:bg-green-500 text-slate-950 font-bold rounded-lg transition-all flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-slate-900/30 border-t-slate-900 rounded-full animate-spin"></div>
                    Uploading...
                  </>
                ) : (
                  <>
                    <UploadCloud className="w-5 h-5" /> Submit File
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
